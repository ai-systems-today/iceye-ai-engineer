# AI Engineer Technical Homework Task

This repository is being implemented strictly against [AI Engineer Technical Homework Task.pdf](AI%20Engineer%20Technical%20Homework%20Task.pdf).

## Scope

The PDF is the governing brief for this repository.

What has been implemented in this session:

- Part 1 document ingestion with `kreuzberg`
- Part 1 named entity detection with `glinker`
- Part 1 local entity persistence to JSON
- Part 1 single-turn CLI chatbot using Pydantic AI and answering only from the stored entity file
- Part 2 connected-component blob detection from a 2D NumPy binary mask
- Part 2 rotated bounding box CSV generation

What has not been completed in this session:

- The two handwritten unit tests required by the PDF
- Final zip packaging of the repository

## Phase Status

This repository was executed against the original 11-phase implementation plan derived from [AI Engineer Technical Homework Task.pdf](AI%20Engineer%20Technical%20Homework%20Task.pdf).

1. Repository skeleton: done
2. Exact dependency pinning: done
3. Part 1 ingestion with `kreuzberg` then `glinker`: done
4. Part 1 structured Pydantic output model: done
5. Part 1 single-turn chatbot logic using only stored entities: done
6. Part 2 blob identification from a 2D NumPy mask: done
7. Part 2 rotated rectangle computation: done
8. Part 2 CSV output generation: done
9. One handwritten unit test per task: not done
10. README with install, execute, and test guidance: partially done
11. Final compliance verification: partially done

Why phases 10 and 11 are only partial:

- Phase 10 is partially done because install and execute instructions are documented, but there is no fully compliant test section yet because the required handwritten tests do not exist.
- Phase 11 is partially done because the implemented code paths were validated, but full end-state PDF compliance still depends on phase 9 and final delivery packaging.

## Session Trace

This section records the work completed from the beginning of the session.

1. Read [AI Engineer Technical Homework Task.pdf](AI%20Engineer%20Technical%20Homework%20Task.pdf) and extracted the task requirements.
2. Confirmed the workspace initially contained only the PDF and a Git repository.
3. Checked Python availability and found that the pre-existing local virtual environment was initially Python 3.14, which is not allowed by the PDF.
4. Verified that Python 3.12 was installed on the machine and used that interpreter for the compliant project setup.
5. Installed `uv` with Python 3.12 because the PDF requires a `uv`-based workflow.
6. Created the initial repository skeleton with [pyproject.toml](pyproject.toml), [README.md](README.md), [REQUIREMENTS_TRACE.md](REQUIREMENTS_TRACE.md), and [tests](tests).
7. Pinned all declared dependencies to exact versions and constrained the project to Python 3.12.
8. Validated the project setup with `py -3.12 -m uv sync`.
9. Implemented Part 1 ingestion in [iceye_ai_engineer/part1_ingest.py](iceye_ai_engineer/part1_ingest.py).
10. Validated that Part 1 extraction runs with `kreuzberg` first, then entity detection with `glinker`, and persists entities locally to [data/part1_entities.json](data/part1_entities.json).
11. Implemented the single-turn Part 1 chatbot in [iceye_ai_engineer/part1_chatbot.py](iceye_ai_engineer/part1_chatbot.py).
12. Validated that the chatbot reads only the stored entity file and returns structured output with a conversational reply, unique entities, and labels.
13. Implemented Part 2 blob processing in [iceye_ai_engineer/part2_blob_boxes.py](iceye_ai_engineer/part2_blob_boxes.py).
14. Validated that Part 2 accepts a 2D NumPy binary mask, identifies connected blobs, computes rotated bounding boxes, and writes `blob_bounding_boxes.csv` with the required columns.
15. Revalidated the repository after implementation with `py -3.12 -m uv sync`.

## Environment

Validated environment for the implemented solution:

- Python: 3.12.10
- Project environment: `.venv`
- Setup command: `uv sync`

The repository was validated using Python 3.12 because the PDF allows only Python 3.12 or 3.13.

## Install

```powershell
uv sync
```

This is the required setup command for the repository state produced in this session.

## Files Added In This Session

- [pyproject.toml](pyproject.toml)
- [REQUIREMENTS_TRACE.md](REQUIREMENTS_TRACE.md)
- [iceye_ai_engineer/part1_ingest.py](iceye_ai_engineer/part1_ingest.py)
- [iceye_ai_engineer/part1_chatbot.py](iceye_ai_engineer/part1_chatbot.py)
- [iceye_ai_engineer/part2_blob_boxes.py](iceye_ai_engineer/part2_blob_boxes.py)
- [data/part1_entities.json](data/part1_entities.json)

## Execute

Part 1 ingestion:

```powershell
uv run python -m iceye_ai_engineer.part1_ingest "AI Engineer Technical Homework Task.pdf" organization location person
```

Expected result:

- Extract text from the PDF with `kreuzberg`
- Detect named entities with `glinker`
- Write the entity store to [data/part1_entities.json](data/part1_entities.json)

Part 1 single-turn chatbot against the stored entity file:

```powershell
uv run python -m iceye_ai_engineer.part1_chatbot data/part1_entities.json "How many mentions of AI Engineer are in the doc?"
```

Expected result:

- Load only the stored entity JSON file
- Return structured JSON with:
  - `reply`
  - `entities`
  - `label` for each entity

Part 2 rotated blob bounding boxes from a 2D NumPy mask stored as a `.npy` file:

```powershell
uv run python -m iceye_ai_engineer.part2_blob_boxes path/to/mask.npy
```

This writes `blob_bounding_boxes.csv` in the repository root.

Expected result:

- Read a 2D NumPy binary mask
- Identify connected blobs
- Write one CSV row per blob with columns:
	- `blob_id`
	- `center_x`
	- `center_y`
	- `width`
	- `height`
	- `angle`

## Run tests

The PDF requires one handwritten unit test per task and explicitly says those tests should be written by the candidate rather than generated by an LLM. That is the remaining unresolved compliance item in this repository state.

Because those tests have not been added yet, there is no compliant test command to document yet.

## Validation Completed

Validated during this session:

- `py -3.12 -m uv sync`
- `uv run python -m iceye_ai_engineer.part1_ingest "AI Engineer Technical Homework Task.pdf" organization location person`
- `uv run python -m iceye_ai_engineer.part1_chatbot data/part1_entities.json "How many mentions of AI Engineer are in the doc?"`
- `uv run python -m iceye_ai_engineer.part2_blob_boxes path/to/mask.npy` on a synthetic validation mask

## Remaining Work

The implementation is not 100% complete against the PDF.

Remaining items:

- Write one handwritten unit test for Part 1 under [tests](tests)
- Write one handwritten unit test for Part 2 under [tests](tests)
- Add the final test execution instructions once those handwritten tests exist
- Create the final zip file for delivery

The [tests](tests) directory exists but is currently empty.

## Requirement Status

For the detailed requirement-by-requirement trace and validation log, see [REQUIREMENTS_TRACE.md](REQUIREMENTS_TRACE.md).
